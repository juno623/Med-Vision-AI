"""Evaluate a fine-tuned model the way the app uses it: beam search (5 candidates) + medicine matching.

    python ocr/evaluate_with_matching.py --data_dir data/RxHandBD-ML --model_dir <path to final_model>

Reports, on the held-out Test_Set:
  * raw CER / WER of the best beam candidate (comparable to the earlier numbers)
  * matched top-1 / top-3 medicine-name accuracy
  * how often the matcher flags a reading for review, and how accurate the NOT-flagged ones are

The reference list is built from Train_Label.csv ONLY, so test labels never leak into it.
Test names that never appear in the training labels cannot be matched; they are reported separately.
"""
import argparse
import csv
import os
import sys

os.environ.setdefault("USE_TF", "0")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import jiwer
import torch
from PIL import Image
from transformers import TrOCRProcessor, VisionEncoderDecoderModel

from matching.medicine_matcher import MedicineMatcher, clean, load_vocab_from_csv, split_name_strength


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--model_dir", required=True)
    ap.add_argument("--beams", type=int, default=5)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0, help="Only evaluate the first N test images (quick check)")
    a = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device} | model: {a.model_dir}")
    try:
        processor = TrOCRProcessor.from_pretrained(a.model_dir)
    except Exception:
        processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
    model = VisionEncoderDecoderModel.from_pretrained(a.model_dir).to(device).eval()

    train_names = load_vocab_from_csv(os.path.join(a.data_dir, "Train_Label.csv"))
    matcher = MedicineMatcher(train_names)
    known = {split_name_strength(n)[0] for n in train_names}
    rows = list(csv.DictReader(open(os.path.join(a.data_dir, "Test_Labels.csv"), newline="", encoding="utf-8")))
    if a.limit:
        rows = rows[:a.limit]
    test_dir = os.path.join(a.data_dir, "Test_Set")

    B = a.beams
    best_text, truth, top1, top3, flagged, in_vocab = [], [], [], [], [], []
    for start in range(0, len(rows), a.batch_size):
        chunk = rows[start:start + a.batch_size]
        images = [Image.open(os.path.join(test_dir, r["Images"])).convert("RGB") for r in chunk]
        pv = processor(images=images, return_tensors="pt").pixel_values.to(device)
        with torch.no_grad():
            out = model.generate(pv, num_beams=B, num_return_sequences=B, max_length=32)
        texts = processor.batch_decode(out, skip_special_tokens=True)
        for j, r in enumerate(chunk):
            cands = texts[j * B:(j + 1) * B]
            res = matcher.match(cands, k=3)
            true_base = split_name_strength(r["Text"])[0]
            names = [clean(n) for n, _ in res.suggestions]
            best_text.append(cands[0]); truth.append(r["Text"])
            top1.append(bool(names) and names[0] == true_base)
            top3.append(true_base in names)
            flagged.append(res.needs_review)
            in_vocab.append(true_base in known)
        if (start // a.batch_size) % 20 == 0:
            print(f"  {min(start + a.batch_size, len(rows))}/{len(rows)} images...")

    n = len(rows)
    pct = lambda xs, mask=None: 100.0 * sum(x for x, m in zip(xs, mask or [True] * len(xs)) if m) / max(1, sum(mask or [1] * len(xs)))
    auto = [not f for f in flagged]
    print("\n" + "=" * 60)
    print(f"Test images evaluated: {n}  (medicine names seen in training: {pct(in_vocab):.1f}%)")
    print(f"Raw OCR (best beam)   CER {jiwer.cer(truth, best_text):.4f}   WER {jiwer.wer(truth, best_text):.4f}")
    print(f"Matched top-1 accuracy: {pct(top1):.1f}%   | top-3 accuracy: {pct(top3):.1f}%   (all test images)")
    print(f"Matched top-1 accuracy: {pct(top1, in_vocab):.1f}%   | top-3 accuracy: {pct(top3, in_vocab):.1f}%   (names seen in training)")
    print(f"Flagged for doctor review: {pct(flagged):.1f}%   | top-1 accuracy of the NOT-flagged ones: {pct(top1, auto):.1f}%")
    print("=" * 60)


if __name__ == "__main__":
    main()
