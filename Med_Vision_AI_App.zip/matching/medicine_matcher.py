"""
Med Vision AI - Medicine Matcher
==================================
Turns noisy OCR output (e.g. "mexciture .") into the closest known medicine
names (e.g. "Nexcital"), with a confidence score and a "needs review" flag.

Why this is the biggest cheap accuracy gain: raw OCR is judged letter by letter
(CER), but a medicine name only has to land on the right entry in the reference
list, and the doctor picks from the top suggestions anyway (Phase 5 + 6 of the report).

Usage:
    vocab = load_vocab_from_csv("data/RxHandBD-ML/Train_Label.csv")
    matcher = MedicineMatcher(vocab)
    result = matcher.match(["mexciture .", "nexcitone"], k=3)   # list = beam-search candidates
    result.suggestions   # [("Nexcital", 0.83), ...]
    result.strength      # "10" if the OCR text ended with a strength number
    result.needs_review  # True when confidence is low or two names are nearly tied
"""
import csv
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

from rapidfuzz.distance import JaroWinkler, Levenshtein

_PARTS = re.compile(r"^(?P<name>.*?)(?:\s+(?P<strength>\d[\w./%-]*))?\s*$")


def clean(text: str) -> str:
    """Lowercase, drop stray punctuation (like the trailing ' .' the model often adds)."""
    t = re.sub(r"[^\w\s./%-]", " ", text.lower())
    return re.sub(r"\s+", " ", t).strip(" .-")


def split_name_strength(text: str) -> Tuple[str, Optional[str]]:
    """'dexter 60' -> ('dexter', '60'). The name is matched; the strength is carried along."""
    t = clean(text)
    m = _PARTS.match(t)
    name = (m.group("name") or "").strip() if m else t
    return (name or t), (m.group("strength") if m else None)


def similarity(a: str, b: str) -> float:
    """Blend of Jaro-Winkler (rewards matching starts) and normalized Levenshtein (edit distance)."""
    return 0.5 * JaroWinkler.similarity(a, b) + 0.5 * Levenshtein.normalized_similarity(a, b)


def load_vocab_from_csv(csv_path: str, column: str = "Text") -> List[str]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        return [row[column] for row in csv.DictReader(f)]


@dataclass
class MatchResult:
    suggestions: List[Tuple[str, float]]   # (medicine name, score 0-1), best first
    strength: Optional[str]
    needs_review: bool

    @property
    def best(self) -> Optional[str]:
        return self.suggestions[0][0] if self.suggestions else None

    @property
    def confidence(self) -> float:
        return self.suggestions[0][1] if self.suggestions else 0.0


class MedicineMatcher:
    def __init__(self, names: List[str], min_confidence: float = 0.80, min_margin: float = 0.05):
        self.min_confidence, self.min_margin = min_confidence, min_margin
        self.names = {}                      # cleaned base name -> display name
        for n in names:
            base, _ = split_name_strength(n)
            if base:
                self.names.setdefault(base, base.title())

    def match(self, candidates, k: int = 3) -> MatchResult:
        """candidates: one OCR string, or a list of beam-search candidates, best first."""
        if isinstance(candidates, str):
            candidates = [candidates]
        best, strength = {}, None
        for rank, cand in enumerate(candidates):
            name, st = split_name_strength(cand)
            if not name:
                continue
            strength = strength or st
            for base in self.names:
                s = similarity(name, base) * (1 - 0.02 * rank)   # slight preference for higher-ranked candidates
                if s > best.get(base, 0.0):
                    best[base] = s
        ranked = sorted(best.items(), key=lambda kv: -kv[1])[:k]
        sugg = [(self.names[b], round(s, 3)) for b, s in ranked]
        unsure = (not sugg or sugg[0][1] < self.min_confidence
                  or (len(sugg) > 1 and sugg[0][1] - sugg[1][1] < self.min_margin))
        return MatchResult(sugg, strength, unsure)
