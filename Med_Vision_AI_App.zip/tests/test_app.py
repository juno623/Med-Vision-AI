"""Automated tests for the Med Vision AI web app (uses the DEMO OCR engine, no GPU or model needed).

Run from the project root:   python -m unittest tests.test_app -v
"""
import io
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("USE_TF", "0")

from PIL import Image, ImageDraw

from app import create_app
from app.models import Medicine, Patient, Prescription, User, db


def png(size=(300, 200)):
    img = Image.new("RGB", size, "white")
    d = ImageDraw.Draw(img)
    for y in range(40, size[1] - 20, 40):
        d.line([(20, y), (size[0] - 30, y + 6)], fill="black", width=3)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        db_path = os.path.join(self.tmp.name, "t.db").replace("\\", "/")
        self.app = create_app({"TESTING": True, "OCR_MODE": "mock", "SQLALCHEMY_DATABASE_URI": "sqlite:///" + db_path,
                               "UPLOAD_DIR": os.path.join(self.tmp.name, "up")})
        with self.app.app_context():
            for n in ["Napa", "Indever", "Losita", "Rivotril", "Econate", "Exeptim", "Nexcital"]:
                db.session.add(Medicine(name=n))
            db.session.commit()
        self.doc = self.make_user("doc@t.test", "doctor")
        self.p1 = self.make_user("p1@t.test", "patient")
        self.p2 = self.make_user("p2@t.test", "patient")

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.engine.dispose()
        self.tmp.cleanup()

    def make_user(self, email, role):
        from app.models import Doctor
        with self.app.app_context():
            u = User(email=email, role=role, name=email.split("@")[0])
            u.set_password("Passw0rd!")
            db.session.add(u)
            db.session.flush()
            db.session.add(Doctor(user_id=u.id) if role == "doctor" else Patient(user_id=u.id))
            db.session.commit()
            return Doctor.query.filter_by(user_id=u.id).first().id if role == "doctor" else Patient.query.filter_by(user_id=u.id).first().id

    def csrf(self, c):
        c.get("/")
        c.get("/login")
        with c.session_transaction() as s:
            return s["csrf"]

    def login(self, email, pw="Passw0rd!"):
        c = self.app.test_client()
        r = c.post("/login", data={"email": email, "password": pw, "csrf": self.csrf(c)})
        return c, r

    def upload(self, c, pid, data=None, name="rx.png"):
        return c.post(f"/doctor/patient/{pid}/upload", content_type="multipart/form-data",
                      data={"csrf": self.csrf(c), "image": (io.BytesIO(data or png()), name)})

    # ---- tests ----
    def test_login_and_wrong_password(self):
        c, r = self.login("doc@t.test")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(c.get("/doctor/").status_code, 200)
        _, bad = self.login("doc@t.test", "wrong-password")
        self.assertIn(b"Invalid email or password", bad.data)

    def test_csrf_required(self):
        r = self.app.test_client().post("/login", data={"email": "doc@t.test", "password": "Passw0rd!"})
        self.assertEqual(r.status_code, 400)

    def test_register_validation(self):
        c = self.app.test_client()
        r = c.post("/register", data={"name": "A", "email": "bad", "password": "short", "role": "patient", "csrf": self.csrf(c)})
        self.assertIn(b"valid email", r.data)

    def test_full_prescription_flow(self):
        c, _ = self.login("doc@t.test")
        r = self.upload(c, self.p1)
        self.assertEqual(r.status_code, 302)
        with self.app.app_context():
            rx = Prescription.query.one()
            self.assertEqual(rx.status, "pending")
            self.assertEqual(len(rx.items), 1)
            self.assertTrue(rx.items[0].suggestions_json != "[]")
            rid, iid = rx.id, rx.items[0].id
        self.assertEqual(c.get(f"/doctor/prescription/{rid}/review").status_code, 200)
        # patient cannot see it while it is still unverified
        pc, _ = self.login("p1@t.test")
        self.assertEqual(pc.get(f"/prescription/{rid}").status_code, 404)
        self.assertEqual(pc.get(f"/prescription/{rid}/image").status_code, 404)
        # doctor reads an extra region
        tok = self.csrf(c)
        r = c.post(f"/doctor/prescription/{rid}/region", json={"x": 10, "y": 10, "w": 100, "h": 60}, headers={"X-CSRF-Token": tok})
        self.assertEqual(r.status_code, 200)
        extra = r.get_json()["id"]
        bad = c.post(f"/doctor/prescription/{rid}/region", json={"x": 10, "y": 10, "w": 2, "h": 2}, headers={"X-CSRF-Token": tok})
        self.assertEqual(bad.status_code, 400)
        # approve: keep first, edit it, drop the extra region
        r = c.post(f"/doctor/prescription/{rid}/verify", headers={"X-CSRF-Token": tok},
                   json={"notes": "ok", "items": [{"id": iid, "name": "Napa", "strength": "500 mg", "dosage": "1 tab", "frequency": "1-0-1", "duration": "5 days"}]})
        self.assertEqual(r.status_code, 200)
        with self.app.app_context():
            rx = db.session.get(Prescription, rid)
            self.assertEqual(rx.status, "verified")
            self.assertEqual([i.final_name for i in rx.items], ["Napa"])
            self.assertIsNone(db.session.get(__import__("app.models", fromlist=["PrescriptionItem"]).PrescriptionItem, extra))
        r = pc.get("/patient")
        self.assertIn(b"Napa", r.data)
        self.assertEqual(pc.get(f"/prescription/{rid}").status_code, 200)
        self.assertEqual(pc.get(f"/prescription/{rid}/image").status_code, 200)

    def test_verify_requires_a_name(self):
        c, _ = self.login("doc@t.test")
        self.upload(c, self.p1)
        with self.app.app_context():
            rx = Prescription.query.one()
            rid, iid = rx.id, rx.items[0].id
        r = c.post(f"/doctor/prescription/{rid}/verify", headers={"X-CSRF-Token": self.csrf(c)}, json={"items": [{"id": iid, "name": " "}]})
        self.assertEqual(r.status_code, 400)

    def test_access_control(self):
        dc, _ = self.login("doc@t.test")
        self.upload(dc, self.p1)
        with self.app.app_context():
            rx = Prescription.query.one()
            rid, iid = rx.id, rx.items[0].id
        dc.post(f"/doctor/prescription/{rid}/verify", headers={"X-CSRF-Token": self.csrf(dc)}, json={"items": [{"id": iid, "name": "Napa"}]})
        other, _ = self.login("p2@t.test")
        self.assertEqual(other.get(f"/prescription/{rid}").status_code, 404)      # another patient's record
        self.assertEqual(other.get("/doctor/").status_code, 403)                  # patient on doctor pages
        self.assertEqual(other.get("/admin/").status_code, 403)
        anon = self.app.test_client()
        self.assertEqual(anon.get("/patient").status_code, 302)                   # redirected to login

    def test_reject_leaves_no_record(self):
        c, _ = self.login("doc@t.test")
        self.upload(c, self.p1)
        with self.app.app_context():
            rid = Prescription.query.one().id
        c.post(f"/doctor/prescription/{rid}/reject", data={"csrf": self.csrf(c)})
        with self.app.app_context():
            self.assertEqual(db.session.get(Prescription, rid).status, "rejected")
        pc, _ = self.login("p1@t.test")
        self.assertEqual(pc.get(f"/prescription/{rid}").status_code, 404)

    def test_rejects_non_images(self):
        c, _ = self.login("doc@t.test")
        self.upload(c, self.p1, data=b"not an image", name="evil.png")
        self.upload(c, self.p1, data=b"MZ", name="evil.exe")
        with self.app.app_context():
            self.assertEqual(Prescription.query.count(), 0)

    def test_large_photo_is_deskewed_and_saved(self):
        c, _ = self.login("doc@t.test")
        self.upload(c, self.p1, data=png((1400, 1000)), name="big.png")
        with self.app.app_context():
            self.assertTrue(Prescription.query.one().image_path.endswith("_work.jpg"))


if __name__ == "__main__":
    unittest.main()
