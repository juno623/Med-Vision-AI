from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from .auth import role_required
from .models import AuditLog, Medicine, User, db
from .utils import audit

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.route("/")
@role_required("admin")
def index():
    return render_template("admin.html", users=User.query.order_by(User.id).all(),
                           logs=AuditLog.query.order_by(AuditLog.id.desc()).limit(60).all(),
                           med_count=Medicine.query.count())


@bp.route("/user/<int:uid>/toggle", methods=["POST"])
@role_required("admin")
def toggle_user(uid):
    user = db.get_or_404(User, uid)
    if user.id == g.user.id:
        flash("You cannot deactivate your own account.", "error")
    else:
        user.is_active_account = not user.is_active_account
        db.session.commit()
        audit("user_toggled", f"user={uid} active={user.is_active_account}")
    return redirect(url_for("admin.index"))


@bp.route("/medicine", methods=["POST"])
@role_required("admin")
def add_medicine():
    name = request.form.get("name", "").strip()[:120].title()
    if not name:
        flash("Enter a medicine name.", "error")
    elif Medicine.query.filter_by(name=name).first():
        flash("That medicine already exists.", "error")
    else:
        db.session.add(Medicine(name=name, generic_name=request.form.get("generic", "").strip()[:120],
                                strength_form=request.form.get("strength", "").strip()[:80]))
        db.session.commit()
        audit("medicine_added", name)
        flash(f"Added {name} to the reference database.", "info")
    return redirect(url_for("admin.index"))
