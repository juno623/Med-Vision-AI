"""OCR layer: preprocessing -> region detection -> TrOCR (beam search, 5 candidates) per region.

If the fine-tuned model cannot be loaded, the app falls back to a clearly-labelled DEMO engine
(placeholder readings) so the rest of the system can still be shown and tested.
"""
import os
import threading
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

PLACEHOLDERS = ["mexciture .", "indever .", "lositre .", "rivotal", "napa", "economic"]


def _imread(path):
    return cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_COLOR)


class MockEngine:
    name = "mock"

    def detect(self, bgr):
        h, w = bgr.shape[:2]
        return [(0, 0, w, h)]

    def recognize(self, pil):
        pick = int(np.asarray(pil).mean()) % len(PLACEHOLDERS)
        return [(PLACEHOLDERS[pick], 0.55), (PLACEHOLDERS[(pick + 1) % len(PLACEHOLDERS)], 0.40)]


class TrOCREngine:
    name = "real"

    def __init__(self, model_dir, num_beams=5, single_max=700):
        os.environ.setdefault("USE_TF", "0")
        import torch
        from transformers import TrOCRProcessor, VisionEncoderDecoderModel
        self.torch = torch
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        try:
            self.processor = TrOCRProcessor.from_pretrained(model_dir)
        except Exception:
            self.processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
        self.model = VisionEncoderDecoderModel.from_pretrained(model_dir).to(self.device).eval()
        self.num_beams, self.single_max = num_beams, single_max
        self.lock, self._detector = threading.Lock(), None

    def recognize(self, pil):
        pil = pil.convert("RGB")
        with self.lock, self.torch.no_grad():
            pv = self.processor(images=pil, return_tensors="pt").pixel_values.to(self.device)
            out = self.model.generate(pv, num_beams=self.num_beams, num_return_sequences=self.num_beams,
                                      max_length=32, output_scores=True, return_dict_in_generate=True)
        texts = self.processor.batch_decode(out.sequences, skip_special_tokens=True)
        scores = out.sequences_scores.exp().tolist()
        return list(zip(texts, scores))

    def detect(self, bgr):
        h, w = bgr.shape[:2]
        if max(h, w) <= self.single_max:
            return [(0, 0, w, h)]
        boxes = []
        try:
            if self._detector is None:
                import easyocr
                self._detector = easyocr.Reader(["en"], gpu=(self.device == "cuda"),
                                                detector=True, recognizer=False, verbose=False)
            horizontal, _ = self._detector.detect(bgr)
            boxes = [(int(x0), int(y0), int(x1 - x0), int(y1 - y0)) for x0, x1, y0, y1 in horizontal[0]]
        except Exception:
            boxes = []
        boxes = sorted([b for b in boxes if b[2] > 15 and b[3] > 10], key=lambda b: (b[1], b[0]))
        return boxes or [(0, 0, w, h)]


class OCRService:
    def __init__(self, cfg):
        self.single_max = cfg["SINGLE_REGION_MAX_SIDE"]
        self.note, self.engine = "", None
        mode = cfg["OCR_MODE"]
        if mode in ("auto", "real"):
            try:
                self.engine = TrOCREngine(cfg["MODEL_DIR"], cfg["NUM_BEAMS"], self.single_max)
                print(f"[OCR] Model loaded from {cfg['MODEL_DIR']} on {self.engine.device}")
            except Exception as e:
                if mode == "real":
                    raise
                self.note = f"(Model not loaded: {type(e).__name__}. Check MODEL_DIR.)"
                print("[OCR] DEMO mode -", self.note)
        if self.engine is None:
            self.engine = MockEngine()

    @property
    def demo(self):
        return self.engine.name == "mock"

    def _read_box(self, img, box, pad=8):
        h, w = img.shape[:2]
        x, y, bw, bh = box
        x0, y0, x1, y1 = max(0, x - pad), max(0, y - pad), min(w, x + bw + pad), min(h, y + bh + pad)
        crop = img[y0:y1, x0:x1]
        pil = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
        return self.engine.recognize(pil)

    def read_image(self, path):
        """Returns (working image path, [(box, candidates), ...]). Big photos are shrunk and
        deskewed first; small word crops are read as-is (that matches how the model was trained)."""
        path = Path(path)
        img = _imread(path)
        if img is None:
            raise ValueError("Unreadable image")
        work = path
        if max(img.shape[:2]) > self.single_max:
            scale = 1600 / max(img.shape[:2])
            if scale < 1:
                img = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            try:
                from preprocessing.pipeline import preprocess_image
                img = preprocess_image(img).deskewed
            except Exception:
                pass
            work = path.with_name(path.stem + "_work.jpg")
            cv2.imwrite(str(work), img, [cv2.IMWRITE_JPEG_QUALITY, 92])
        return work, [(b, self._read_box(img, b)) for b in self.engine.detect(img)]

    def read_region(self, path, box):
        img = _imread(path)
        if img is None:
            return None
        h, w = img.shape[:2]
        x, y, bw, bh = box
        x, y = max(0, x), max(0, y)
        bw, bh = min(bw, w - x), min(bh, h - y)
        if bw < 8 or bh < 8:
            return None
        return (x, y, bw, bh), self._read_box(img, (x, y, bw, bh))
