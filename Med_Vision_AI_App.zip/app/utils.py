import uuid
from flask import g, current_app
from .models import db, AuditLog


def audit(action, detail=""):
    user = getattr(g, "user", None)
    db.session.add(AuditLog(user_id=user.id if user else None, action=action, detail=str(detail)[:500]))
    db.session.commit()


def allowed_file(name):
    return "." in name and name.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]


def new_name(ext):
    return f"{uuid.uuid4().hex}.{ext}"
