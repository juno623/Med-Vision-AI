(function () {
  const cfg = window.REVIEW;
  const csrf = document.querySelector('meta[name="csrf"]').content;
  const img = document.getElementById("rx-img"), canvas = document.getElementById("overlay");
  const ctx = canvas.getContext("2d"), tbody = document.getElementById("rows"), statusEl = document.getElementById("status");
  let items = cfg.items.slice(), selected = null, drag = null;

  const el = (tag, props, kids) => { const e = document.createElement(tag); Object.assign(e, props || {}); (kids || []).forEach(k => e.append(k)); return e; };
  const setStatus = (msg, bad) => { statusEl.textContent = msg; statusEl.className = bad ? "bad" : "muted"; };
  const post = (url, body) => fetch(url, { method: "POST", headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf }, body: JSON.stringify(body) });
  const scale = () => img.clientWidth / (img.naturalWidth || 1);

  function field(it, key, ph) {
    return el("input", { value: it[key] || "", placeholder: ph, oninput: e => { it[key] = e.target.value; } });
  }

  function render() {
    tbody.innerHTML = "";
    items.forEach((it, i) => {
      const name = el("input", { value: it.final_name || "", oninput: e => { it.final_name = e.target.value; } });
      const chips = el("div", { className: "chips" }, (it.suggestions || []).map(s =>
        el("button", { type: "button", className: "chip", textContent: s[0] + " " + Math.round(s[1] * 100) + "%",
          onclick: () => { it.final_name = s[0]; render(); } })));
      const pct = Math.round((it.match_confidence || 0) * 100);
      const badge = el("span", { className: "badge " + (it.needs_review ? "check" : "ok"), textContent: (it.needs_review ? "Check " : "OK ") + pct + "%" });
      const del = el("button", { type: "button", className: "link", textContent: "Remove", onclick: ev => { ev.stopPropagation(); items.splice(i, 1); selected = null; render(); } });
      const tr = el("tr", { className: i === selected ? "sel" : "", onclick: () => { selected = i; draw(); } }, [
        el("td", { textContent: String(i + 1) }), el("td", { className: "raw", textContent: it.ocr_text || "" }),
        el("td", { className: "name" }, [name, chips]), el("td", {}, [field(it, "strength", "500 mg")]),
        el("td", {}, [field(it, "dosage", "1 tab")]), el("td", {}, [field(it, "frequency", "1-0-1")]),
        el("td", {}, [field(it, "duration", "5 days")]), el("td", {}, [badge]), el("td", {}, [del])]);
      tbody.append(tr);
    });
    draw();
  }

  function draw() {
    canvas.width = img.clientWidth; canvas.height = img.clientHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const s = scale();
    items.forEach((it, i) => {
      if (!it.box || it.box.length < 4) return;
      const [x, y, w, h] = it.box, hot = i === selected;
      ctx.lineWidth = hot ? 3 : 2; ctx.strokeStyle = ctx.fillStyle = hot ? "#ff6b5e" : "#0e7c86";
      ctx.strokeRect(x * s, y * s, w * s, h * s); ctx.font = "bold 14px sans-serif"; ctx.fillText(String(i + 1), x * s + 3, y * s + 14);
    });
    if (drag) { ctx.strokeStyle = "#ff6b5e"; ctx.setLineDash([5, 4]); ctx.strokeRect(drag.x0, drag.y0, drag.x1 - drag.x0, drag.y1 - drag.y0); ctx.setLineDash([]); }
  }

  const pos = e => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  canvas.addEventListener("pointerdown", e => { const [x, y] = pos(e); drag = { x0: x, y0: y, x1: x, y1: y }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointermove", e => { if (!drag) return; [drag.x1, drag.y1] = pos(e); draw(); });
  canvas.addEventListener("pointerup", async () => {
    if (!drag) return;
    const d = drag, s = scale(); drag = null;
    const box = { x: Math.round(Math.min(d.x0, d.x1) / s), y: Math.round(Math.min(d.y0, d.y1) / s), w: Math.round(Math.abs(d.x1 - d.x0) / s), h: Math.round(Math.abs(d.y1 - d.y0) / s) };
    draw();
    if (box.w < 10 || box.h < 10) return;
    setStatus("Reading the selected region...");
    try {
      const res = await post(cfg.regionUrl, box), data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not read that region.");
      items.push(data); selected = items.length - 1; render(); setStatus("Region added. Check the suggestion.");
    } catch (err) { setStatus(err.message, true); }
  });

  document.getElementById("approve").addEventListener("click", async () => {
    if (!items.length) { setStatus("Add at least one medicine first.", true); return; }
    if (!confirm("Approve these medicines and store them in the patient's record?")) return;
    const payload = { notes: document.getElementById("notes").value,
      items: items.map(it => ({ id: it.id, name: it.final_name, strength: it.strength, dosage: it.dosage, frequency: it.frequency, duration: it.duration })) };
    try {
      const res = await post(cfg.verifyUrl, payload), data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not approve.");
      window.location.href = data.redirect;
    } catch (err) { setStatus(err.message, true); }
  });

  img.addEventListener("load", render); window.addEventListener("resize", draw);
  if (img.complete) render();
})();
