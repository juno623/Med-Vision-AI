import hmac
import secrets
from pathlib import Path

from flask import Flask, abort, g, render_template, request, session

from config import BASE_DIR, Config
from .models import User, db


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)

    (BASE_DIR / "instance").mkdir(exist_ok=True)
    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    with app.app_context():
        db.create_all()

    from .ocr_service import OCRService
    app.extensions["ocr"] = OCRService(app.config)

    from . import admin, auth, doctor, patient
    for module in (auth, doctor, patient, admin):
        app.register_blueprint(module.bp)

    @app.before_request
    def load_user_and_check_csrf():
        g.user = db.session.get(User, session["uid"]) if "uid" in session else None
        if g.user is not None and not g.user.is_active_account:
            session.clear()
            g.user = None
        if request.method == "POST":
            sent = request.form.get("csrf") or request.headers.get("X-CSRF-Token") or ""
            if not sent or not hmac.compare_digest(session.get("csrf", "").encode(), sent.encode()):
                abort(400, "Security token missing or expired. Reload the page and try again.")

    @app.context_processor
    def inject():
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        ocr = app.extensions["ocr"]
        return dict(csrf_token=session["csrf"], me=getattr(g, "user", None),
                    demo_mode=ocr.demo, ocr_note=ocr.note)

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def show_error(err):
        code = getattr(err, "code", 500)
        msg = {400: "The request could not be processed.", 403: "You do not have access to this page.",
               404: "Page not found.", 413: "That file is too large (10 MB maximum)."}.get(code, "Something went wrong.")
        detail = getattr(err, "description", "") if code == 400 else ""
        return render_template("error.html", code=code, message=msg, detail=detail), code

    for c in (400, 403, 404, 413):
        app.register_error_handler(c, show_error)
    return app
