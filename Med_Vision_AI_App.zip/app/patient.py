from pathlib import Path

from flask import Blueprint, abort, current_app, g, render_template, send_file

from .auth import login_required, role_required
from .models import Prescription, db

bp = Blueprint("patient", __name__)


def _can_view(rx):
    if g.user.role == "doctor":
        return True
    return g.user.role == "patient" and g.user.patient and rx.patient_id == g.user.patient.id and rx.status == "verified"


@bp.route("/patient")
@role_required("patient")
def dashboard():
    p = g.user.patient
    verified = [r for r in p.prescriptions if r.status == "verified"]
    return render_template("patient_dashboard.html", p=p, verified=verified)


@bp.route("/prescription/<int:rid>")
@login_required
def view_prescription(rid):
    rx = db.get_or_404(Prescription, rid)
    if not _can_view(rx):
        abort(403 if g.user.role != "patient" else 404)
    return render_template("prescription_view.html", rx=rx)


@bp.route("/prescription/<int:rid>/image")
@login_required
def image(rid):
    rx = db.get_or_404(Prescription, rid)
    if not _can_view(rx):
        abort(403 if g.user.role != "patient" else 404)
    if not rx.image_path:
        abort(404)
    path = Path(current_app.config["UPLOAD_DIR"]) / Path(rx.image_path).name
    if not path.exists():
        abort(404)
    return send_file(path)
