import secrets
from datetime import datetime, timezone
from pathlib import Path

from flask import (Blueprint, abort, current_app, flash, g, jsonify, redirect, render_template,
                   request, url_for)
from PIL import Image

from .auth import EMAIL, role_required
from .models import HistoryEntry, Patient, Prescription, User, db, utcnow
from .services import get_matcher, item_dict, make_item
from .utils import allowed_file, audit, new_name

bp = Blueprint("doctor", __name__, url_prefix="/doctor")


def _clip(value, n):
    return str(value or "").strip()[:n]


@bp.route("/")
@role_required("doctor")
def dashboard():
    q = request.args.get("q", "").strip().lower()
    results = []
    if q:
        results = (Patient.query.join(User, Patient.user_id == User.id)
                   .filter(User.email.like(f"%{q}%")).limit(20).all())
    recent = (Prescription.query.filter_by(doctor_id=g.user.doctor.id)
              .order_by(Prescription.id.desc()).limit(8).all())
    return render_template("doctor_dashboard.html", q=q, results=results, recent=recent)


@bp.route("/patients/new", methods=["GET", "POST"])
@role_required("doctor")
def new_patient():
    if request.method == "POST":
        f = request.form
        name, email = _clip(f.get("name"), 120), _clip(f.get("email"), 120).lower()
        if not name or not EMAIL.match(email):
            flash("Enter the patient's name and a valid email address.", "error")
        elif User.query.filter_by(email=email).first():
            flash("A user with that email already exists. Search for them instead.", "error")
        else:
            temp = secrets.token_urlsafe(9)
            user = User(email=email, name=name, role="patient")
            user.set_password(temp)
            db.session.add(user)
            db.session.flush()
            patient = Patient(user_id=user.id, dob=_clip(f.get("dob"), 20), gender=_clip(f.get("gender"), 20),
                              phone=_clip(f.get("phone"), 30), allergies=_clip(f.get("allergies"), 500))
            db.session.add(patient)
            db.session.commit()
            audit("patient_registered", email)
            flash(f"Patient registered. Temporary password (shown once): {temp}", "info")
            return redirect(url_for("doctor.patient_detail", pid=patient.id))
    return render_template("doctor_new_patient.html")


@bp.route("/patient/<int:pid>")
@role_required("doctor")
def patient_detail(pid):
    return render_template("doctor_patient.html", p=db.get_or_404(Patient, pid))


@bp.route("/patient/<int:pid>/history", methods=["POST"])
@role_required("doctor")
def add_history(pid):
    p = db.get_or_404(Patient, pid)
    f = request.form
    if not (f.get("diagnosis") or f.get("treatment") or f.get("notes")):
        flash("Enter a diagnosis, treatment or note.", "error")
    else:
        entry = HistoryEntry(patient_id=p.id, doctor_id=g.user.doctor.id, diagnosis=_clip(f.get("diagnosis"), 300),
                             treatment=_clip(f.get("treatment"), 300), allergies=_clip(f.get("allergies"), 300),
                             notes=_clip(f.get("notes"), 1000))
        if f.get("visit_date", "").strip():
            entry.visit_date = _clip(f.get("visit_date"), 20)
        if entry.allergies:
            p.allergies = entry.allergies
        db.session.add(entry)
        db.session.commit()
        audit("history_added", f"patient={p.id}")
        flash("History entry added.", "info")
    return redirect(url_for("doctor.patient_detail", pid=pid))


@bp.route("/patient/<int:pid>/upload", methods=["POST"])
@role_required("doctor")
def upload(pid):
    p = db.get_or_404(Patient, pid)
    f = request.files.get("image")
    if not f or not f.filename or not allowed_file(f.filename):
        flash("Please choose a JPG or PNG image.", "error")
        return redirect(url_for("doctor.patient_detail", pid=pid))
    path = Path(current_app.config["UPLOAD_DIR"]) / new_name(f.filename.rsplit(".", 1)[1].lower())
    f.save(path)
    try:
        Image.open(path).verify()
        work_path, regions = current_app.extensions["ocr"].read_image(path)
    except Exception as e:
        path.unlink(missing_ok=True)
        flash(f"Could not process that image ({type(e).__name__}). Try a clearer photo.", "error")
        return redirect(url_for("doctor.patient_detail", pid=pid))
    ocr = current_app.extensions["ocr"]
    rx = Prescription(patient_id=p.id, doctor_id=g.user.doctor.id, image_path=work_path.name,
                      status="pending", ocr_mode=ocr.engine.name)
    db.session.add(rx)
    db.session.flush()
    matcher = get_matcher()
    for box, candidates in regions:
        db.session.add(make_item(rx.id, box, candidates, matcher))
    db.session.commit()
    audit("prescription_uploaded", f"rx={rx.id} patient={p.id}")
    return redirect(url_for("doctor.review", rid=rx.id))


@bp.route("/prescription/<int:rid>/review")
@role_required("doctor")
def review(rid):
    rx = db.get_or_404(Prescription, rid)
    if rx.status != "pending":
        return redirect(url_for("patient.view_prescription", rid=rid))
    cfg = {"items": [item_dict(i) for i in rx.items],
           "imageUrl": url_for("patient.image", rid=rid), "regionUrl": url_for("doctor.region", rid=rid),
           "verifyUrl": url_for("doctor.verify", rid=rid)}
    return render_template("review.html", rx=rx, cfg=cfg)


@bp.route("/prescription/<int:rid>/region", methods=["POST"])
@role_required("doctor")
def region(rid):
    rx = db.get_or_404(Prescription, rid)
    if rx.status != "pending" or not rx.image_path:
        abort(400)
    data = request.get_json(silent=True) or {}
    try:
        box = tuple(int(data[k]) for k in ("x", "y", "w", "h"))
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Invalid region."), 400
    found = current_app.extensions["ocr"].read_region(Path(current_app.config["UPLOAD_DIR"]) / rx.image_path, box)
    if found is None:
        return jsonify(error="That region is too small or outside the image."), 400
    clipped, candidates = found
    item = make_item(rx.id, clipped, candidates, get_matcher())
    db.session.add(item)
    db.session.commit()
    return jsonify(item_dict(item))


@bp.route("/prescription/<int:rid>/verify", methods=["POST"])
@role_required("doctor")
def verify(rid):
    rx = db.get_or_404(Prescription, rid)
    if rx.status != "pending":
        abort(400)
    rows = (request.get_json(silent=True) or {}).get("items")
    notes = (request.get_json(silent=True) or {}).get("notes", "")
    if not isinstance(rows, list) or not rows:
        return jsonify(error="Add at least one medicine before approving."), 400
    existing = {i.id: i for i in rx.items}
    keep = set()
    for r in rows:
        item = existing.get(r.get("id")) if isinstance(r, dict) else None
        if item is None:
            continue
        name = _clip(r.get("name"), 120)
        if not name:
            return jsonify(error="Every medicine needs a name (or delete that row)."), 400
        item.final_name, item.strength = name, _clip(r.get("strength"), 40)
        item.dosage, item.frequency, item.duration = _clip(r.get("dosage"), 60), _clip(r.get("frequency"), 60), _clip(r.get("duration"), 60)
        keep.add(item.id)
    if not keep:
        return jsonify(error="Nothing to approve."), 400
    for iid, item in existing.items():
        if iid not in keep:
            db.session.delete(item)
    rx.status, rx.verified_at, rx.notes = "verified", utcnow(), _clip(notes, 1000)
    db.session.commit()
    audit("prescription_verified", f"rx={rx.id}")
    return jsonify(ok=True, redirect=url_for("patient.view_prescription", rid=rx.id))


@bp.route("/prescription/<int:rid>/reject", methods=["POST"])
@role_required("doctor")
def reject(rid):
    rx = db.get_or_404(Prescription, rid)
    if rx.status == "pending":
        rx.status = "rejected"
        db.session.commit()
        audit("prescription_rejected", f"rx={rx.id}")
        flash("Prescription rejected. Nothing was added to the patient's record.", "info")
    return redirect(url_for("doctor.patient_detail", pid=rx.patient_id))
