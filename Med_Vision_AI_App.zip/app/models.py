from datetime import datetime, timezone, date
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)          # doctor | patient | admin
    name = db.Column(db.String(120), nullable=False)
    is_active_account = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=utcnow)
    patient = db.relationship("Patient", backref="user", uselist=False)
    doctor = db.relationship("Doctor", backref="user", uselist=False)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)


class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False)
    dob = db.Column(db.String(20))
    gender = db.Column(db.String(20))
    phone = db.Column(db.String(30))
    allergies = db.Column(db.Text)
    history = db.relationship("HistoryEntry", backref="patient", order_by="HistoryEntry.id.desc()")
    prescriptions = db.relationship("Prescription", backref="patient", order_by="Prescription.id.desc()")


class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False)
    specialization = db.Column(db.String(120))


class HistoryEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False, index=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor.id"))
    visit_date = db.Column(db.String(20), default=lambda: date.today().isoformat())
    diagnosis = db.Column(db.String(300))
    treatment = db.Column(db.String(300))
    allergies = db.Column(db.String(300))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow)
    doctor = db.relationship("Doctor")


class Medicine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False, index=True)
    generic_name = db.Column(db.String(120))
    strength_form = db.Column(db.String(80))


class Prescription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False, index=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor.id"), nullable=False)
    image_path = db.Column(db.String(200))                    # file name only, inside UPLOAD_DIR
    status = db.Column(db.String(20), default="pending")      # pending | verified | rejected
    ocr_mode = db.Column(db.String(20))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow)
    verified_at = db.Column(db.DateTime)
    doctor = db.relationship("Doctor")
    items = db.relationship("PrescriptionItem", backref="prescription", cascade="all, delete-orphan",
                            order_by="PrescriptionItem.id")


class PrescriptionItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    prescription_id = db.Column(db.Integer, db.ForeignKey("prescription.id"), nullable=False, index=True)
    box_json = db.Column(db.String(80))
    ocr_text = db.Column(db.String(200))
    ocr_confidence = db.Column(db.Float, default=0.0)
    suggestions_json = db.Column(db.Text, default="[]")
    match_confidence = db.Column(db.Float, default=0.0)
    needs_review = db.Column(db.Boolean, default=True)
    final_name = db.Column(db.String(120))
    strength = db.Column(db.String(40))
    dosage = db.Column(db.String(60))
    frequency = db.Column(db.String(60))
    duration = db.Column(db.String(60))


class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    action = db.Column(db.String(60))
    detail = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=utcnow)
    user = db.relationship("User")
