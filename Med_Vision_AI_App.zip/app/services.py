import json
from sqlalchemy import func
from matching.medicine_matcher import MedicineMatcher
from .models import db, Medicine, PrescriptionItem

_cache = {"n": -1, "matcher": None}


def get_matcher():
    """Matcher built from the Medicine table; rebuilt automatically when medicines are added."""
    n = db.session.query(func.count(Medicine.id)).scalar()
    if _cache["n"] != n or _cache["matcher"] is None:
        _cache["matcher"] = MedicineMatcher([m.name for m in Medicine.query.all()])
        _cache["n"] = n
    return _cache["matcher"]


def make_item(rx_id, box, candidates, matcher):
    texts = [c[0] for c in candidates]
    ocr_conf = float(candidates[0][1]) if candidates else 0.0
    m = matcher.match(texts, k=3)
    return PrescriptionItem(
        prescription_id=rx_id, box_json=json.dumps([int(v) for v in box]),
        ocr_text=texts[0] if texts else "", ocr_confidence=ocr_conf,
        suggestions_json=json.dumps(m.suggestions), match_confidence=float(m.confidence),
        needs_review=bool(m.needs_review or ocr_conf < 0.5),
        final_name=m.best or (texts[0] if texts else ""), strength=m.strength or "")


def item_dict(i):
    return {"id": i.id, "box": json.loads(i.box_json or "[]"), "ocr_text": i.ocr_text,
            "ocr_confidence": i.ocr_confidence, "suggestions": json.loads(i.suggestions_json or "[]"),
            "match_confidence": i.match_confidence, "needs_review": i.needs_review,
            "final_name": i.final_name or "", "strength": i.strength or "", "dosage": i.dosage or "",
            "frequency": i.frequency or "", "duration": i.duration or ""}
