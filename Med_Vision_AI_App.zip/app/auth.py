import functools
import re

from flask import Blueprint, abort, flash, g, redirect, render_template, request, session, url_for

from .models import Doctor, Patient, User, db
from .utils import audit

bp = Blueprint("auth", __name__)
EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
HOME = {"doctor": "doctor.dashboard", "patient": "patient.dashboard", "admin": "admin.index"}


def login_required(f):
    @functools.wraps(f)
    def wrapper(*a, **k):
        if not g.user:
            return redirect(url_for("auth.login"))
        return f(*a, **k)
    return wrapper


def role_required(*roles):
    def deco(f):
        @functools.wraps(f)
        def wrapper(*a, **k):
            if not g.user:
                return redirect(url_for("auth.login"))
            if g.user.role not in roles:
                abort(403)
            return f(*a, **k)
        return wrapper
    return deco


@bp.route("/")
def index():
    return redirect(url_for(HOME[g.user.role])) if g.user else redirect(url_for("auth.login"))


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user and user.is_active_account and user.check_password(request.form.get("password", "")):
            session.clear()
            session["uid"] = user.id
            g.user = user
            audit("login", email)
            return redirect(url_for(HOME[user.role]))
        g.user = None
        audit("login_failed", email)
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        name, email, pw, role = f.get("name", "").strip(), f.get("email", "").strip().lower(), f.get("password", ""), f.get("role", "")
        error = None
        if not name:
            error = "Please enter your name."
        elif not EMAIL.match(email):
            error = "Please enter a valid email address."
        elif len(pw) < 8:
            error = "Password must be at least 8 characters."
        elif role not in ("patient", "doctor"):
            error = "Choose Patient or Doctor."
        elif User.query.filter_by(email=email).first():
            error = "That email is already registered."
        if error:
            flash(error, "error")
        else:
            user = User(email=email, name=name, role=role)
            user.set_password(pw)
            db.session.add(user)
            db.session.flush()
            if role == "patient":
                db.session.add(Patient(user_id=user.id, dob=f.get("dob", "").strip(), gender=f.get("gender", "").strip()))
            else:
                db.session.add(Doctor(user_id=user.id, specialization=f.get("specialization", "").strip()))
            db.session.commit()
            flash("Account created. You can log in now.", "info")
            return redirect(url_for("auth.login"))
    return render_template("register.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
